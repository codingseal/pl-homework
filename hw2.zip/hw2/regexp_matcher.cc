// PL homework: hw2
// regexp_matcher.cc

#include "regexp_matcher.h"

bool BuildRegExpMatcher(const char* regexp, RegExpMatcher* regexp_matcher) {
  return false;
}

bool RunRegExpMatcher(const RegExpMatcher* regexp_matcher, const char* str) {
  return false;
}

