// PL homework: hw1
// fsa.cc

#include <iostream>
#include <string.h>
#include "fsa.h"
#define LOG \
    if (DISABLE_LOG) {} else std::cerr

const char kEps = '#';

using namespace std;

bool CheckIfNFA(const TableElement* elements, int num_elements) {
  // Implement this function.
  return false;
}

bool BuildDFA(const TableElement* elements, int num_elements,
              const int* accept_states, int num_accept_states,
              FiniteStateAutomaton* fsa) {
  // Check the number of elements
  cout << "num_elements: " << num_elements << endl;
  if (num_elements <= 0) return false;
  
  // Set the initial state
  fsa->initial_state = elements[0].state;

  // Set the transition functions
  for (int i = 0; i < num_elements; i++) 
    fsa->transitions[make_pair(elements[i].state, elements[i].input_char)] = elements[i].next_state; 
  
  // Set the final states
  for (int i = 0; i < num_accept_states; i++)
    fsa->final_states.insert(accept_states[i]);

  return true;
}

bool BuildNFA(const TableElement* elements, int num_elements,
              const int* accept_states_array, int num_accept_states,
              FiniteStateAutomaton* fsa) {
  // Implement this function.
  return false;
}

// Homework 1.1
bool RunFSA(const FiniteStateAutomaton* fsa, const char* str) {
  int current_state = fsa->initial_state;
  int i = 0;
  int length = strlen(str);
  bool undefined = false;
  map<pair<int, char>, int>::const_iterator it;
  while (!undefined && i < length) {
    if ((it = fsa->transitions.find(make_pair(current_state, str[i]))) != fsa->transitions.end()) {
        current_state = it->second;
	    i++;
    }
	else
      undefined = true;
  }
  
  if (!undefined && fsa->final_states.find(current_state) != fsa->final_states.end()) 
	return true;
  else 
    return false;
}

// Homework 1.1 and 1.2
bool BuildFSA(const TableElement* elements, int num_elements,
              const int* accept_states, int num_accepts,
              FiniteStateAutomaton* fsa) {
  if (CheckIfNFA(elements, num_elements)) {
    return BuildNFA(elements, num_elements, accept_states, num_accepts, fsa);
  } else {
    return BuildDFA(elements, num_elements, accept_states, num_accepts, fsa);
  }
}

// Homework 1.3
bool BuildFSA(const char* regex, FiniteStateAutomaton* fsa) {
  // Implement this function.
  return false;
}

